require 'rails_helper'

RSpec.describe PostsController, type: :controller do

end
