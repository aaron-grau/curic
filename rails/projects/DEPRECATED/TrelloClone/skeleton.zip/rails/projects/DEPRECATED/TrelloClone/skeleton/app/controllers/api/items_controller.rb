module Api
  class ItemsController < ApiController
  end
end
