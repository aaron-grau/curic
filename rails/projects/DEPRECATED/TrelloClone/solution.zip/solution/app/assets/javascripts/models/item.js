TrelloClone.Models.Item = Backbone.Model.extend({
  urlRoot: '/api/items'
});
