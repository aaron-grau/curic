# Solutions for Rails Auth Homework

* Look in app/model to find the user.rb file
* Look in db/migrate to find the migration file
