class Cat < ActiveRecord::Base
  include Toyable
end
