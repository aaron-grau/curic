class Corgi < ApplicationRecord
  include Toyable
end
