class Corgi < ActiveRecord::Base
  include Toyable
end
