module.exports = {
  entry: "./lib/main.js",
  output: {
    path: __dirname,
    filename: "jquery_lite.js"
	},
	devtool: "source-map"
};
