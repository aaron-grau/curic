 * [Reversi Bonus Solution][reversi-bonus-solution]
 * [:movie_camera: (cc) Make Change (Ruby)][make-change]
 * [:movie_camera: (cc) Subsets (Ruby)][subsets]

[reversi-bonus-solution]: 
https://github.com/appacademy/curriculum/tree/master/javascript/projects/js_reversi/solution
[make-change]: https://vimeo.com/groups/appacademy/videos/91207646
[subsets]: https://vimeo.com/groups/appacademy/videos/91207645

