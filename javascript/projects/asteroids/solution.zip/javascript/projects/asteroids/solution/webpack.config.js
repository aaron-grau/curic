module.exports = {
  entry: "./lib/asteroids.js",
  output: {
  	filename: "./lib/bundle.js"
  },
  devtool: 'source-map',
};
