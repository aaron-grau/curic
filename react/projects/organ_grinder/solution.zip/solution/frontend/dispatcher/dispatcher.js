const Dispatcher = require('flux').Dispatcher;
const AppDispatcher = new Dispatcher();

module.exports = AppDispatcher;
