import { hashHistory } from 'react-router';

export default hashHistory;
