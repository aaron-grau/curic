/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 147);
/******/ })
/************************************************************************/
/******/ ({

/***/ 14:
/***/ (function(module, __webpack_exports__) {

"use strict";
throw new Error("Module build failed: Error: ENOENT: no such file or directory, open '/Users/louiscruz/Desktop/app-academy-repos/curriculum/react/projects/bench_bnb/solution/node_modules/react-router-dom/es/index.js'");

/***/ }),

/***/ 145:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = __webpack_require__(3);

var _react2 = _interopRequireDefault(_react);

var _reactRedux = __webpack_require__(17);

var _reactRouterDom = __webpack_require__(14);

var _app = __webpack_require__(148);

var _app2 = _interopRequireDefault(_app);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Root = function Root(_ref) {
  var store = _ref.store;
  return _react2.default.createElement(
    _reactRedux.Provider,
    { store: store },
    _react2.default.createElement(
      _reactRouterDom.HashRouter,
      null,
      _react2.default.createElement(_app2.default, null)
    )
  );
};

exports.default = Root;

/***/ }),

/***/ 146:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _redux = __webpack_require__(80);

var _reduxThunk = __webpack_require__(372);

var _reduxThunk2 = _interopRequireDefault(_reduxThunk);

var _root_reducer = __webpack_require__(167);

var _root_reducer2 = _interopRequireDefault(_root_reducer);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var configureStore = function configureStore() {
  var preloadedState = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  return (0, _redux.createStore)(_root_reducer2.default, preloadedState, (0, _redux.applyMiddleware)(_reduxThunk2.default));
};

exports.default = configureStore;

/***/ }),

/***/ 147:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _react = __webpack_require__(3);

var _react2 = _interopRequireDefault(_react);

var _reactDom = __webpack_require__(82);

var _reactDom2 = _interopRequireDefault(_reactDom);

var _root = __webpack_require__(145);

var _root2 = _interopRequireDefault(_root);

var _store = __webpack_require__(146);

var _store2 = _interopRequireDefault(_store);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//Components
//React
document.addEventListener('DOMContentLoaded', function () {
  var store = void 0;
  if (window.currentUser) {
    var preloadedState = { session: { currentUser: window.currentUser } };
    store = (0, _store2.default)(preloadedState);
    delete window.currentUser;
  } else {
    store = (0, _store2.default)();
  }
  var root = document.getElementById('root');
  _reactDom2.default.render(_react2.default.createElement(_root2.default, { store: store }), root);
});

/***/ }),

/***/ 148:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = __webpack_require__(3);

var _react2 = _interopRequireDefault(_react);

var _reactRedux = __webpack_require__(17);

var _reactRouterDom = __webpack_require__(14);

var _greeting_container = __webpack_require__(157);

var _greeting_container2 = _interopRequireDefault(_greeting_container);

var _session_form_container = __webpack_require__(164);

var _session_form_container2 = _interopRequireDefault(_session_form_container);

var _search_container = __webpack_require__(162);

var _search_container2 = _interopRequireDefault(_search_container);

var _bench_show_container = __webpack_require__(85);

var _bench_show_container2 = _interopRequireDefault(_bench_show_container);

var _bench_form_container = __webpack_require__(150);

var _bench_form_container2 = _interopRequireDefault(_bench_form_container);

var _route_util = __webpack_require__(87);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var App = function App() {
  return _react2.default.createElement(
    'div',
    null,
    _react2.default.createElement(
      'header',
      null,
      _react2.default.createElement(
        _reactRouterDom.Link,
        { to: '/', className: 'header-link' },
        _react2.default.createElement(
          'h1',
          null,
          'Bench BnB'
        )
      ),
      _react2.default.createElement(_greeting_container2.default, null)
    ),
    _react2.default.createElement(
      _reactRouterDom.Switch,
      null,
      _react2.default.createElement(_route_util.AuthRoute, { path: '/login', component: _session_form_container2.default }),
      _react2.default.createElement(_route_util.AuthRoute, { path: '/signup', component: _session_form_container2.default }),
      _react2.default.createElement(_route_util.ProtectedRoute, { path: '/benches/new', component: _bench_form_container2.default }),
      _react2.default.createElement(_reactRouterDom.Route, { path: '/benches/:benchId', component: _bench_show_container2.default }),
      _react2.default.createElement(_reactRouterDom.Route, { exact: true, path: '/', component: _search_container2.default })
    )
  );
};

exports.default = App;

/***/ }),

/***/ 149:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = __webpack_require__(3);

var _react2 = _interopRequireDefault(_react);

var _reactRouter = __webpack_require__(9);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var BenchForm = function (_React$Component) {
  _inherits(BenchForm, _React$Component);

  function BenchForm(props) {
    _classCallCheck(this, BenchForm);

    var _this = _possibleConstructorReturn(this, (BenchForm.__proto__ || Object.getPrototypeOf(BenchForm)).call(this, props));

    _this.coords = { lat: props.lat, lng: props.lng };
    _this.state = {
      description: '',
      picture_url: '',
      seating: 2
    };
    _this.handleSubmit = _this.handleSubmit.bind(_this);
    _this.navigateToSearch = _this.navigateToSearch.bind(_this);
    _this.handleCloudinary = _this.handleCloudinary.bind(_this);
    return _this;
  }

  _createClass(BenchForm, [{
    key: 'navigateToSearch',
    value: function navigateToSearch() {
      this.props.history.push('/');
    }
  }, {
    key: 'update',
    value: function update(property) {
      var _this2 = this;

      return function (e) {
        return _this2.setState(_defineProperty({}, property, e.target.value));
      };
    }
  }, {
    key: 'handleCloudinary',
    value: function handleCloudinary(e) {
      var _this3 = this;

      e.preventDefault();
      cloudinary.openUploadWidget(CLOUDINARY_OPTIONS, function (error, results) {
        if (error) console.log(error);else _this3.setState({ picture_url: results[0].secure_url });
      });
    }
  }, {
    key: 'handleSubmit',
    value: function handleSubmit(e) {
      e.preventDefault();
      var bench = Object.assign({}, this.state, this.coords);
      this.props.createBench({ bench: bench });
      this.navigateToSearch();
    }
  }, {
    key: 'render',
    value: function render() {
      var _state = this.state,
          description = _state.description,
          picture_url = _state.picture_url,
          seating = _state.seating;
      var _coords = this.coords,
          lat = _coords.lat,
          lng = _coords.lng;


      return _react2.default.createElement(
        'div',
        { className: 'new-bench-container' },
        _react2.default.createElement(
          'div',
          { className: 'new-bench-form' },
          _react2.default.createElement(
            'h3',
            { className: 'new-bench-title' },
            'Create A Bench!'
          ),
          _react2.default.createElement(
            'form',
            { onSubmit: this.handleSubmit },
            _react2.default.createElement(
              'label',
              { className: 'bench-field' },
              'Description'
            ),
            _react2.default.createElement('input', {
              type: 'text',
              value: description,
              onChange: this.update('description'),
              className: 'bench-field'
            }),
            _react2.default.createElement(
              'label',
              { className: 'bench-field' },
              'Number of Seats'
            ),
            _react2.default.createElement('input', {
              min: '0',
              type: 'number',
              value: seating,
              onChange: this.update('seating'),
              className: 'bench-field'
            }),
            _react2.default.createElement(
              'label',
              { className: 'bench-field' },
              'Latitude'
            ),
            _react2.default.createElement('input', {
              type: 'text',
              disabled: true,
              value: lat,
              className: 'bench-field'
            }),
            _react2.default.createElement(
              'label',
              { className: 'bench-field' },
              'Longitude'
            ),
            _react2.default.createElement('input', {
              type: 'text',
              disabled: true,
              value: lng,
              className: 'bench-field'
            }),
            _react2.default.createElement(
              'div',
              { className: 'button-holder' },
              _react2.default.createElement(
                'button',
                {
                  onClick: this.handleCloudinary,
                  className: 'new-bench-button'
                },
                'Add image'
              )
            ),
            _react2.default.createElement('hr', null),
            _react2.default.createElement(
              'div',
              { className: 'button-holder' },
              _react2.default.createElement('input', {
                type: 'submit',
                value: 'Create Bench',
                className: 'new-bench-button'
              })
            )
          ),
          _react2.default.createElement(
            'div',
            { className: 'button-holder' },
            _react2.default.createElement(
              'button',
              {
                className: 'new-bench-button',
                onClick: this.navigateToSearch
              },
              'Cancel'
            )
          )
        )
      );
    }
  }]);

  return BenchForm;
}(_react2.default.Component);

exports.default = (0, _reactRouter.withRouter)(BenchForm);

/***/ }),

/***/ 150:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _reactRedux = __webpack_require__(17);

var _bench_actions = __webpack_require__(28);

var _bench_form = __webpack_require__(149);

var _bench_form2 = _interopRequireDefault(_bench_form);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var mapStateToProps = function mapStateToProps(state, _ref) {
  var location = _ref.location;
  return {
    lat: new URLSearchParams(location.search).get('lat'),
    lng: new URLSearchParams(location.search).get('lng')
  };
};

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    createBench: function createBench(bench) {
      return dispatch((0, _bench_actions.createBench)(bench));
    }
  };
};

exports.default = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(_bench_form2.default);

/***/ }),

/***/ 151:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = __webpack_require__(3);

var _react2 = _interopRequireDefault(_react);

var _reactRouter = __webpack_require__(9);

var _review_show = __webpack_require__(155);

var _review_show2 = _interopRequireDefault(_review_show);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var reviewList = function reviewList() {
  var reviews = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  return reviews.map(function (review) {
    return _react2.default.createElement(_review_show2.default, {
      rating: review.rating,
      body: review.body,
      key: review.id
    });
  });
};

var BenchDetail = function BenchDetail(_ref) {
  var bench = _ref.bench;

  return _react2.default.createElement(
    'div',
    null,
    _react2.default.createElement(
      'ul',
      { className: 'bench-list' },
      _react2.default.createElement('img', { className: 'index-image', src: bench.picture_url }),
      _react2.default.createElement(
        'li',
        null,
        'Rating: ',
        bench.average_rating || 'No reviews yet'
      ),
      _react2.default.createElement(
        'li',
        null,
        'Description: ',
        bench.description
      ),
      _react2.default.createElement(
        'li',
        null,
        'Seats: ',
        bench.seating
      ),
      _react2.default.createElement(
        'li',
        null,
        'Latitude: ',
        bench.lat
      ),
      _react2.default.createElement(
        'li',
        null,
        'Longitude: ',
        bench.lng
      )
    ),
    _react2.default.createElement('br', null),
    _react2.default.createElement(
      'div',
      { className: 'reviews' },
      _react2.default.createElement(
        'h3',
        null,
        'Reviews'
      ),
      reviewList(bench.reviews)
    )
  );
};

exports.default = BenchDetail;

/***/ }),

/***/ 152:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = __webpack_require__(3);

var _react2 = _interopRequireDefault(_react);

var _reactRouterDom = __webpack_require__(14);

var _bench_detail = __webpack_require__(151);

var _bench_detail2 = _interopRequireDefault(_bench_detail);

var _bench_map = __webpack_require__(84);

var _bench_map2 = _interopRequireDefault(_bench_map);

var _review_form_container = __webpack_require__(154);

var _review_form_container2 = _interopRequireDefault(_review_form_container);

var _route_util = __webpack_require__(87);

var _link_util = __webpack_require__(170);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var BenchShow = function BenchShow(_ref) {
  var bench = _ref.bench,
      benchId = _ref.benchId,
      fetchBench = _ref.fetchBench;

  var benches = _defineProperty({}, benchId, bench);

  return _react2.default.createElement(
    'div',
    { className: 'single-bench-show' },
    _react2.default.createElement(
      'div',
      { className: 'single-bench-map' },
      _react2.default.createElement(
        _reactRouterDom.Link,
        { to: '/' },
        'Back to Benches Index'
      ),
      _react2.default.createElement(_bench_map2.default, {
        benches: benches,
        benchId: benchId,
        singleBench: true,
        fetchBench: fetchBench
      })
    ),
    _react2.default.createElement(
      'div',
      { className: 'right-half bench-details' },
      _react2.default.createElement(_bench_detail2.default, { bench: bench }),
      _react2.default.createElement(_link_util.ReviewLink, {
        component: _review_form_container2.default,
        to: '/benches/' + benchId + '/review',
        label: 'Leave a Review'
      }),
      _react2.default.createElement(_route_util.ProtectedRoute, {
        path: '/benches/:benchId/review',
        component: _review_form_container2.default
      })
    )
  );
};

exports.default = BenchShow;

/***/ }),

/***/ 153:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = __webpack_require__(3);

var _react2 = _interopRequireDefault(_react);

var _reactRouterDom = __webpack_require__(14);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ReviewForm = function (_React$Component) {
  _inherits(ReviewForm, _React$Component);

  function ReviewForm(props) {
    _classCallCheck(this, ReviewForm);

    var _this = _possibleConstructorReturn(this, (ReviewForm.__proto__ || Object.getPrototypeOf(ReviewForm)).call(this, props));

    _this.state = {
      rating: 5,
      body: ''
    };
    _this.handleSubmit = _this.handleSubmit.bind(_this);
    _this.navigateToBenchShow = _this.navigateToBenchShow.bind(_this);
    return _this;
  }

  _createClass(ReviewForm, [{
    key: 'navigateToBenchShow',
    value: function navigateToBenchShow() {
      var url = '/benches/' + this.props.match.params.benchId;
      this.props.history.push(url);
    }
  }, {
    key: 'handleSubmit',
    value: function handleSubmit(e) {
      e.preventDefault();
      var benchId = parseInt(this.props.match.params.benchId);
      var review = Object.assign({}, this.state, {
        bench_id: benchId
      });
      this.props.createReview({ review: review });
      this.navigateToBenchShow();
    }
  }, {
    key: 'update',
    value: function update(property) {
      var _this2 = this;

      return function (e) {
        return _this2.setState(_defineProperty({}, property, e.currentTarget.value));
      };
    }
  }, {
    key: 'render',
    value: function render() {
      return _react2.default.createElement(
        'div',
        { className: 'review-form' },
        _react2.default.createElement(
          'form',
          { onSubmit: this.handleSubmit },
          _react2.default.createElement(
            'label',
            null,
            'Rating'
          ),
          _react2.default.createElement('br', null),
          _react2.default.createElement('input', {
            type: 'number',
            value: this.state.rating,
            onChange: this.update("rating")
          }),
          _react2.default.createElement('br', null),
          _react2.default.createElement(
            'label',
            null,
            'Comment'
          ),
          _react2.default.createElement('br', null),
          _react2.default.createElement('textarea', {
            cols: '30',
            rows: '10',
            value: this.state.body,
            onChange: this.update("body")
          }),
          _react2.default.createElement('br', null),
          _react2.default.createElement('input', { type: 'submit' })
        ),
        _react2.default.createElement(
          'button',
          { onClick: this.navigateToBenchShow },
          'Cancel'
        )
      );
    }
  }]);

  return ReviewForm;
}(_react2.default.Component);

exports.default = (0, _reactRouterDom.withRouter)(ReviewForm);

/***/ }),

/***/ 154:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _reactRedux = __webpack_require__(17);

var _bench_actions = __webpack_require__(28);

var _review_form = __webpack_require__(153);

var _review_form2 = _interopRequireDefault(_review_form);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    createReview: function createReview(review) {
      return dispatch((0, _bench_actions.createReview)(review));
    }
  };
};

exports.default = (0, _reactRedux.connect)(null, mapDispatchToProps)(_review_form2.default);

/***/ }),

/***/ 155:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = __webpack_require__(3);

var _react2 = _interopRequireDefault(_react);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Review = function Review(_ref) {
  var rating = _ref.rating,
      body = _ref.body;
  return _react2.default.createElement(
    'div',
    null,
    _react2.default.createElement(
      'ul',
      null,
      _react2.default.createElement(
        'li',
        null,
        'Rating: ',
        rating
      ),
      _react2.default.createElement(
        'li',
        null,
        body
      )
    )
  );
};

exports.default = Review;

/***/ }),

/***/ 156:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = __webpack_require__(3);

var _react2 = _interopRequireDefault(_react);

var _reactRouterDom = __webpack_require__(14);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var sessionLinks = function sessionLinks() {
  return _react2.default.createElement(
    'nav',
    { className: 'login-signup' },
    _react2.default.createElement(
      _reactRouterDom.Link,
      { to: '/login' },
      'Login'
    ),
    '\xA0or\xA0',
    _react2.default.createElement(
      _reactRouterDom.Link,
      { to: '/signup' },
      'Sign up!'
    )
  );
};

var personalGreeting = function personalGreeting(currentUser, logout) {
  return _react2.default.createElement(
    'hgroup',
    { className: 'header-group' },
    _react2.default.createElement(
      'h2',
      { className: 'header-name' },
      'Hi, ',
      currentUser.username,
      '!'
    ),
    _react2.default.createElement(
      'button',
      { className: 'header-button', onClick: logout },
      'Log Out'
    )
  );
};

var Greeting = function Greeting(_ref) {
  var currentUser = _ref.currentUser,
      logout = _ref.logout;
  return currentUser ? personalGreeting(currentUser, logout) : sessionLinks();
};

exports.default = Greeting;

/***/ }),

/***/ 157:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _reactRedux = __webpack_require__(17);

var _session_actions = __webpack_require__(37);

var _greeting = __webpack_require__(156);

var _greeting2 = _interopRequireDefault(_greeting);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var mapStateToProps = function mapStateToProps(_ref) {
  var session = _ref.session;
  return {
    currentUser: session.currentUser
  };
};

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    logout: function logout() {
      return dispatch((0, _session_actions.logout)());
    }
  };
};

exports.default = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(_greeting2.default);

/***/ }),

/***/ 158:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = __webpack_require__(3);

var _react2 = _interopRequireDefault(_react);

var _bench_index_item = __webpack_require__(159);

var _bench_index_item2 = _interopRequireDefault(_bench_index_item);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var BenchIndex = function BenchIndex(_ref) {
  var benches = _ref.benches;
  return _react2.default.createElement(
    'div',
    null,
    _react2.default.createElement(
      'h1',
      null,
      'Benches: '
    ),
    benches.map(function (bench) {
      return _react2.default.createElement(_bench_index_item2.default, {
        bench: bench,
        key: bench.id
      });
    })
  );
};

exports.default = BenchIndex;

/***/ }),

/***/ 159:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = __webpack_require__(3);

var _react2 = _interopRequireDefault(_react);

var _reactRouterDom = __webpack_require__(14);

var _bench_show_container = __webpack_require__(85);

var _bench_show_container2 = _interopRequireDefault(_bench_show_container);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var IndexItem = function (_React$Component) {
  _inherits(IndexItem, _React$Component);

  function IndexItem(props) {
    _classCallCheck(this, IndexItem);

    var _this = _possibleConstructorReturn(this, (IndexItem.__proto__ || Object.getPrototypeOf(IndexItem)).call(this, props));

    _this.handleClick = _this.handleClick.bind(_this);
    return _this;
  }

  _createClass(IndexItem, [{
    key: 'handleClick',
    value: function handleClick() {
      var benchId = this.props.bench.id;
      this.props.history.push('/benches/' + benchId);
    }
  }, {
    key: 'render',
    value: function render() {
      var _props$bench = this.props.bench,
          average_rating = _props$bench.average_rating,
          description = _props$bench.description,
          picture_url = _props$bench.picture_url;

      return _react2.default.createElement(
        'div',
        {
          className: 'bench-index-item',
          onClick: this.handleClick
        },
        _react2.default.createElement(
          'div',
          { className: 'index-item-info' },
          _react2.default.createElement(
            'span',
            { className: 'index-item-category' },
            'Rating:'
          ),
          _react2.default.createElement(
            'span',
            { className: 'index-item-copy' },
            average_rating || 'No reviews yet'
          ),
          _react2.default.createElement(
            'span',
            { className: 'index-item-category' },
            'Description:'
          ),
          _react2.default.createElement(
            'span',
            { className: 'index-item-copy' },
            description
          )
        ),
        _react2.default.createElement('img', { src: picture_url })
      );
    }
  }]);

  return IndexItem;
}(_react2.default.Component);

exports.default = (0, _reactRouterDom.withRouter)(IndexItem);

/***/ }),

/***/ 160:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = __webpack_require__(3);

var _react2 = _interopRequireDefault(_react);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var handleChange = function handleChange(filter, updateFilter) {
  return function (e) {
    return updateFilter(filter, e.currentTarget.value);
  };
};

var FilterForm = function FilterForm(_ref) {
  var minSeating = _ref.minSeating,
      maxSeating = _ref.maxSeating,
      updateFilter = _ref.updateFilter;
  return _react2.default.createElement(
    "div",
    null,
    _react2.default.createElement(
      "span",
      { className: "filter" },
      "Filter results:"
    ),
    _react2.default.createElement("br", null),
    _react2.default.createElement(
      "label",
      null,
      "Minimum Seats"
    ),
    _react2.default.createElement("input", {
      type: "number",
      value: minSeating,
      onChange: handleChange('minSeating', updateFilter)
    }),
    _react2.default.createElement("br", null),
    _react2.default.createElement(
      "label",
      null,
      "Maximum Seats"
    ),
    _react2.default.createElement("input", {
      type: "number",
      value: maxSeating,
      onChange: handleChange('maxSeating', updateFilter)
    })
  );
};

exports.default = FilterForm;

/***/ }),

/***/ 161:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = __webpack_require__(3);

var _react2 = _interopRequireDefault(_react);

var _filter_form = __webpack_require__(160);

var _filter_form2 = _interopRequireDefault(_filter_form);

var _bench_index = __webpack_require__(158);

var _bench_index2 = _interopRequireDefault(_bench_index);

var _bench_map = __webpack_require__(84);

var _bench_map2 = _interopRequireDefault(_bench_map);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Search = function Search(_ref) {
  var benches = _ref.benches,
      minSeating = _ref.minSeating,
      maxSeating = _ref.maxSeating,
      updateFilter = _ref.updateFilter;
  return _react2.default.createElement(
    'div',
    { className: 'user-pane' },
    _react2.default.createElement(
      'div',
      { className: 'left-half' },
      _react2.default.createElement(
        'h5',
        null,
        'Click Map to Add Bench!'
      ),
      _react2.default.createElement(_bench_map2.default, {
        benches: benches,
        updateFilter: updateFilter,
        singleBench: false
      })
    ),
    _react2.default.createElement(
      'div',
      { className: 'right-half' },
      _react2.default.createElement(_filter_form2.default, {
        minSeating: minSeating,
        maxSeating: maxSeating,
        updateFilter: updateFilter
      }),
      _react2.default.createElement(_bench_index2.default, { benches: benches })
    )
  );
};

exports.default = Search;

/***/ }),

/***/ 162:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _reactRedux = __webpack_require__(17);

var _filter_actions = __webpack_require__(83);

var _selectors = __webpack_require__(86);

var _search = __webpack_require__(161);

var _search2 = _interopRequireDefault(_search);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var mapStateToProps = function mapStateToProps(state) {
  return {
    benches: (0, _selectors.asArray)(state),
    minSeating: state.filters.minSeating,
    maxSeating: state.filters.maxSeating
  };
};

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    updateFilter: function updateFilter(filter, value) {
      return dispatch((0, _filter_actions.updateFilter)(filter, value));
    }
  };
};

exports.default = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(_search2.default);

/***/ }),

/***/ 163:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = __webpack_require__(3);

var _react2 = _interopRequireDefault(_react);

var _reactRouterDom = __webpack_require__(14);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var SessionForm = function (_React$Component) {
  _inherits(SessionForm, _React$Component);

  function SessionForm(props) {
    _classCallCheck(this, SessionForm);

    var _this = _possibleConstructorReturn(this, (SessionForm.__proto__ || Object.getPrototypeOf(SessionForm)).call(this, props));

    _this.state = {
      username: '',
      password: ''
    };
    _this.handleSubmit = _this.handleSubmit.bind(_this);
    return _this;
  }

  _createClass(SessionForm, [{
    key: 'componentWillReceiveProps',
    value: function componentWillReceiveProps(nextProps) {
      if (nextProps.loggedIn) {
        this.props.history.push('/');
      }
    }
  }, {
    key: 'update',
    value: function update(field) {
      var _this2 = this;

      return function (e) {
        return _this2.setState(_defineProperty({}, field, e.currentTarget.value));
      };
    }
  }, {
    key: 'handleSubmit',
    value: function handleSubmit(e) {
      e.preventDefault();
      var user = this.state;
      this.props.processForm({ user: user });
    }
  }, {
    key: 'navLink',
    value: function navLink() {
      if (this.props.formType === 'login') {
        return _react2.default.createElement(
          _reactRouterDom.Link,
          { to: '/signup' },
          'sign up instead'
        );
      } else {
        return _react2.default.createElement(
          _reactRouterDom.Link,
          { to: '/login' },
          'log in instead'
        );
      }
    }
  }, {
    key: 'renderErrors',
    value: function renderErrors() {
      return _react2.default.createElement(
        'ul',
        null,
        this.props.errors.map(function (error, i) {
          return _react2.default.createElement(
            'li',
            { key: 'error-' + i },
            error
          );
        })
      );
    }
  }, {
    key: 'render',
    value: function render() {
      return _react2.default.createElement(
        'div',
        { className: 'login-form-container' },
        _react2.default.createElement(
          'form',
          { onSubmit: this.handleSubmit, className: 'login-form-box' },
          'Welcome to BenchBnB!',
          _react2.default.createElement('br', null),
          'Please ',
          this.props.formType,
          ' or ',
          this.navLink(),
          this.renderErrors(),
          _react2.default.createElement(
            'div',
            { className: 'login-form' },
            _react2.default.createElement('br', null),
            _react2.default.createElement(
              'label',
              null,
              'Username:',
              _react2.default.createElement('input', { type: 'text',
                value: this.state.username,
                onChange: this.update('username'),
                className: 'login-input'
              })
            ),
            _react2.default.createElement('br', null),
            _react2.default.createElement(
              'label',
              null,
              'Password:',
              _react2.default.createElement('input', { type: 'password',
                value: this.state.password,
                onChange: this.update('password'),
                className: 'login-input'
              })
            ),
            _react2.default.createElement('br', null),
            _react2.default.createElement('input', { type: 'submit', value: 'Submit' })
          )
        )
      );
    }
  }]);

  return SessionForm;
}(_react2.default.Component);

exports.default = (0, _reactRouterDom.withRouter)(SessionForm);

/***/ }),

/***/ 164:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _reactRedux = __webpack_require__(17);

var _session_actions = __webpack_require__(37);

var _session_form = __webpack_require__(163);

var _session_form2 = _interopRequireDefault(_session_form);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var mapStateToProps = function mapStateToProps(_ref) {
  var session = _ref.session;

  return {
    loggedIn: Boolean(session.currentUser),
    errors: session.errors
  };
};

var mapDispatchToProps = function mapDispatchToProps(dispatch, _ref2) {
  var location = _ref2.location;

  var formType = location.pathname.slice(1);
  var _processForm = formType === 'login' ? _session_actions.login : _session_actions.signup;
  return {
    processForm: function processForm(user) {
      return dispatch(_processForm(user));
    },
    formType: formType
  };
};

exports.default = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(_session_form2.default);

/***/ }),

/***/ 165:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _merge = __webpack_require__(59);

var _merge2 = _interopRequireDefault(_merge);

var _bench_actions = __webpack_require__(28);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var BenchesReducer = function BenchesReducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var action = arguments[1];

  Object.freeze(state);
  var newState = (0, _merge2.default)({}, state);

  switch (action.type) {
    case _bench_actions.RECEIVE_BENCHES:
      return action.benches;
    case _bench_actions.RECEIVE_BENCH:
      var newBench = _defineProperty({}, action.bench.id, action.bench);
      return (0, _merge2.default)({}, state, newBench);
    case _bench_actions.RECEIVE_REVIEW:
      var review = action.review;
      newState[review.bench_id].reviews.push(review);
      return newState;
    default:
      return state;
  }
};

exports.default = BenchesReducer;

/***/ }),

/***/ 166:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _merge = __webpack_require__(59);

var _merge2 = _interopRequireDefault(_merge);

var _filter_actions = __webpack_require__(83);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var defaultFilters = Object.freeze({
  bounds: {},
  minSeating: 1,
  maxSeating: 10
});

var FiltersReducer = function FiltersReducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : defaultFilters;
  var action = arguments[1];

  Object.freeze(state);
  if (action.type === _filter_actions.UPDATE_FILTER) {
    var newFilter = _defineProperty({}, action.filter, action.value);
    return (0, _merge2.default)({}, state, newFilter);
  } else {
    return state;
  }
};

exports.default = FiltersReducer;

/***/ }),

/***/ 167:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _redux = __webpack_require__(80);

var _benches_reducer = __webpack_require__(165);

var _benches_reducer2 = _interopRequireDefault(_benches_reducer);

var _filters_reducer = __webpack_require__(166);

var _filters_reducer2 = _interopRequireDefault(_filters_reducer);

var _session_reducer = __webpack_require__(168);

var _session_reducer2 = _interopRequireDefault(_session_reducer);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var RootReducer = (0, _redux.combineReducers)({
  benches: _benches_reducer2.default,
  filters: _filters_reducer2.default,
  session: _session_reducer2.default
});

exports.default = RootReducer;

/***/ }),

/***/ 168:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _merge = __webpack_require__(59);

var _merge2 = _interopRequireDefault(_merge);

var _session_actions = __webpack_require__(37);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var nullUser = Object.freeze({
  currentUser: null,
  errors: []
});

var SessionReducer = function SessionReducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : nullUser;
  var action = arguments[1];

  Object.freeze(state);
  switch (action.type) {
    case _session_actions.RECEIVE_CURRENT_USER:
      var currentUser = action.currentUser;
      return (0, _merge2.default)({}, nullUser, {
        currentUser: currentUser
      });
    case _session_actions.RECEIVE_ERRORS:
      var errors = action.errors;
      return (0, _merge2.default)({}, nullUser, {
        errors: errors
      });
    default:
      return state;
  }
};

exports.default = SessionReducer;

/***/ }),

/***/ 169:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var fetchBenches = exports.fetchBenches = function fetchBenches(data) {
  return $.ajax({
    method: 'GET',
    url: 'api/benches',
    data: data
  });
};

var fetchBench = exports.fetchBench = function fetchBench(id) {
  return $.ajax({
    method: 'GET',
    url: 'api/benches/' + id
  });
};

var createReview = exports.createReview = function createReview(data) {
  return $.ajax({
    method: 'POST',
    url: 'api/reviews',
    data: data
  });
};

var createBench = exports.createBench = function createBench(data) {
  return $.ajax({
    method: 'POST',
    url: 'api/benches',
    data: data
  });
};

/***/ }),

/***/ 17:
/***/ (function(module, exports) {

"use strict";
throw new Error("Module build failed: Error: ENOENT: no such file or directory, open '/Users/louiscruz/Desktop/app-academy-repos/curriculum/react/projects/bench_bnb/solution/node_modules/react-redux/lib/index.js'");

/***/ }),

/***/ 170:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ReviewLink = undefined;

var _react = __webpack_require__(3);

var _react2 = _interopRequireDefault(_react);

var _reactRouterDom = __webpack_require__(14);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var ReviewLink = exports.ReviewLink = function ReviewLink(_ref) {
  var label = _ref.label,
      to = _ref.to;
  return _react2.default.createElement(_reactRouterDom.Route, { path: to, children: function children(_ref2) {
      var match = _ref2.match;
      return _react2.default.createElement(
        'div',
        null,
        match ? "" : _react2.default.createElement(
          _reactRouterDom.Link,
          { to: to },
          label
        )
      );
    } });
};

/***/ }),

/***/ 171:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/* global google:false */

var MarkerManager = function () {
  function MarkerManager(map, handleClick) {
    _classCallCheck(this, MarkerManager);

    this.map = map;
    this.handleClick = handleClick;
    this.markers = {};
  }

  _createClass(MarkerManager, [{
    key: 'updateMarkers',
    value: function updateMarkers(benches) {
      var _this = this;

      var benchesObj = {};
      benches.forEach(function (bench) {
        return benchesObj[bench.id] = bench;
      });

      benches.filter(function (bench) {
        return !_this.markers[bench.id];
      }).forEach(function (newBench) {
        return _this.createMarkerFromBench(newBench, _this.handleClick);
      });

      Object.keys(this.markers).filter(function (benchId) {
        return !benchesObj[benchId];
      }).forEach(function (benchId) {
        return _this.removeMarker(_this.markers[benchId]);
      });
    }
  }, {
    key: 'createMarkerFromBench',
    value: function createMarkerFromBench(bench) {
      var _this2 = this;

      var position = new google.maps.LatLng(bench.lat, bench.lng);
      var marker = new google.maps.Marker({
        position: position,
        map: this.map,
        benchId: bench.id
      });

      marker.addListener('click', function () {
        return _this2.handleClick(bench);
      });
      this.markers[marker.benchId] = marker;
    }
  }, {
    key: 'removeMarker',
    value: function removeMarker(marker) {
      this.markers[marker.benchId].setMap(null);
      delete this.markers[marker.benchId];
    }
  }]);

  return MarkerManager;
}();

exports.default = MarkerManager;

/***/ }),

/***/ 172:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.logout = exports.signup = exports.login = undefined;

var _session_actions = __webpack_require__(37);

var login = exports.login = function login(user) {
  return $.ajax({
    method: 'POST',
    url: '/api/session',
    data: user
  });
};

var signup = exports.signup = function signup(user) {
  return $.ajax({
    method: 'POST',
    url: '/api/user',
    data: user
  });
};

var logout = exports.logout = function logout() {
  return $.ajax({
    method: 'DELETE',
    url: '/api/session'
  });
};

/***/ }),

/***/ 28:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createBench = exports.fetchBench = exports.fetchBenches = exports.createReview = exports.receiveReview = exports.receiveBench = exports.receiveBenches = exports.RECEIVE_REVIEW = exports.RECEIVE_BENCH = exports.RECEIVE_BENCHES = undefined;

var _bench_api_util = __webpack_require__(169);

var APIUtil = _interopRequireWildcard(_bench_api_util);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var RECEIVE_BENCHES = exports.RECEIVE_BENCHES = 'RECEIVE_BENCHES';
var RECEIVE_BENCH = exports.RECEIVE_BENCH = 'RECEIVE_BENCH';
var RECEIVE_REVIEW = exports.RECEIVE_REVIEW = 'RECEIVE_REVIEW';

var receiveBenches = exports.receiveBenches = function receiveBenches(benches) {
  return {
    type: RECEIVE_BENCHES,
    benches: benches
  };
};

var receiveBench = exports.receiveBench = function receiveBench(bench) {
  return {
    type: RECEIVE_BENCH,
    bench: bench
  };
};

var receiveReview = exports.receiveReview = function receiveReview(review) {
  return {
    type: RECEIVE_REVIEW,
    review: review
  };
};

var createReview = exports.createReview = function createReview(review) {
  return function (dispatch) {
    return APIUtil.createReview(review).then(function (review) {
      return dispatch(receiveReview(review));
    });
  };
};

var fetchBenches = exports.fetchBenches = function fetchBenches(filters) {
  return function (dispatch) {
    return APIUtil.fetchBenches(filters).then(function (benches) {
      return dispatch(receiveBenches(benches));
    });
  };
};

var fetchBench = exports.fetchBench = function fetchBench(id) {
  return function (dispatch) {
    return APIUtil.fetchBench(id).then(function (bench) {
      return dispatch(receiveBench(bench));
    });
  };
};

var createBench = exports.createBench = function createBench(bench) {
  return function (dispatch) {
    return APIUtil.createBench(bench).then(function (bench) {
      return dispatch(receiveBench(bench));
    });
  };
};

/***/ }),

/***/ 3:
/***/ (function(module, exports) {

"use strict";
throw new Error("Module build failed: Error: ENOENT: no such file or directory, open '/Users/louiscruz/Desktop/app-academy-repos/curriculum/react/projects/bench_bnb/solution/node_modules/react/react.js'");

/***/ }),

/***/ 37:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.logout = exports.login = exports.signup = exports.receiveErrors = exports.receiveCurrentUser = exports.RECEIVE_ERRORS = exports.RECEIVE_CURRENT_USER = undefined;

var _session_api_util = __webpack_require__(172);

var APIUtil = _interopRequireWildcard(_session_api_util);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var RECEIVE_CURRENT_USER = exports.RECEIVE_CURRENT_USER = 'RECEIVE_CURRENT_USER';
var RECEIVE_ERRORS = exports.RECEIVE_ERRORS = 'RECEIVE_ERRORS';

var receiveCurrentUser = exports.receiveCurrentUser = function receiveCurrentUser(currentUser) {
  return {
    type: RECEIVE_CURRENT_USER,
    currentUser: currentUser
  };
};

var receiveErrors = exports.receiveErrors = function receiveErrors(errors) {
  return {
    type: RECEIVE_ERRORS,
    errors: errors
  };
};

var signup = exports.signup = function signup(user) {
  return function (dispatch) {
    return APIUtil.signup(user).then(function (user) {
      return dispatch(receiveCurrentUser(user));
    }, function (err) {
      return dispatch(receiveErrors(err.responseJSON));
    });
  };
};

var login = exports.login = function login(user) {
  return function (dispatch) {
    return APIUtil.login(user).then(function (user) {
      return dispatch(receiveCurrentUser(user));
    }, function (err) {
      return dispatch(receiveErrors(err.responseJSON));
    });
  };
};

var logout = exports.logout = function logout() {
  return function (dispatch) {
    return APIUtil.logout().then(function (user) {
      return dispatch(receiveCurrentUser(null));
    });
  };
};

/***/ }),

/***/ 372:
/***/ (function(module, exports) {

"use strict";
throw new Error("Module build failed: Error: ENOENT: no such file or directory, open '/Users/louiscruz/Desktop/app-academy-repos/curriculum/react/projects/bench_bnb/solution/node_modules/redux-thunk/lib/index.js'");

/***/ }),

/***/ 59:
/***/ (function(module, exports) {

throw new Error("Module build failed: Error: ENOENT: no such file or directory, open '/Users/louiscruz/Desktop/app-academy-repos/curriculum/react/projects/bench_bnb/solution/node_modules/lodash/merge.js'");

/***/ }),

/***/ 80:
/***/ (function(module, __webpack_exports__) {

"use strict";
throw new Error("Module build failed: Error: ENOENT: no such file or directory, open '/Users/louiscruz/Desktop/app-academy-repos/curriculum/react/projects/bench_bnb/solution/node_modules/redux/es/index.js'");

/***/ }),

/***/ 82:
/***/ (function(module, exports) {

"use strict";
throw new Error("Module build failed: Error: ENOENT: no such file or directory, open '/Users/louiscruz/Desktop/app-academy-repos/curriculum/react/projects/bench_bnb/solution/node_modules/react-dom/index.js'");

/***/ }),

/***/ 83:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.updateFilter = exports.changeFilter = exports.UPDATE_FILTER = undefined;

var _bench_actions = __webpack_require__(28);

var UPDATE_FILTER = exports.UPDATE_FILTER = 'UPDATE_FILTER';

var changeFilter = exports.changeFilter = function changeFilter(filter, value) {
  return {
    type: UPDATE_FILTER,
    filter: filter,
    value: value
  };
};

var updateFilter = exports.updateFilter = function updateFilter(filter, value) {
  return function (dispatch, getState) {
    dispatch(changeFilter(filter, value));
    return (0, _bench_actions.fetchBenches)(getState().filters)(dispatch);
  };
};

/***/ }),

/***/ 84:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = __webpack_require__(3);

var _react2 = _interopRequireDefault(_react);

var _reactDom = __webpack_require__(82);

var _reactDom2 = _interopRequireDefault(_reactDom);

var _reactRouterDom = __webpack_require__(14);

var _marker_manager = __webpack_require__(171);

var _marker_manager2 = _interopRequireDefault(_marker_manager);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var getCoordsObj = function getCoordsObj(latLng) {
  return {
    lat: latLng.lat(),
    lng: latLng.lng()
  };
};

var mapOptions = {
  center: {
    lat: 37.773972,
    lng: -122.431297
  }, // San Francisco coords
  zoom: 13
};

var BenchMap = function (_React$Component) {
  _inherits(BenchMap, _React$Component);

  function BenchMap() {
    _classCallCheck(this, BenchMap);

    return _possibleConstructorReturn(this, (BenchMap.__proto__ || Object.getPrototypeOf(BenchMap)).apply(this, arguments));
  }

  _createClass(BenchMap, [{
    key: 'componentDidMount',
    value: function componentDidMount() {
      var map = this.refs.map;
      this.map = new google.maps.Map(map, mapOptions);
      this.MarkerManager = new _marker_manager2.default(this.map, this.handleMarkerClick.bind(this));
      if (this.props.singleBench) {
        this.props.fetchBench(this.props.benchId);
      } else {
        this.registerListeners();
        this.MarkerManager.updateMarkers(this.props.benches);
      }
    }
  }, {
    key: 'componentDidUpdate',
    value: function componentDidUpdate() {
      if (this.props.singleBench) {
        var targetBenchKey = Object.keys(this.props.benches)[0];
        var targetBench = this.props.benches[targetBenchKey];
        this.MarkerManager.updateMarkers([targetBench]); //grabs only that one bench
      } else {
        this.MarkerManager.updateMarkers(this.props.benches);
      }
    }
  }, {
    key: 'registerListeners',
    value: function registerListeners() {
      var _this2 = this;

      google.maps.event.addListener(this.map, 'idle', function () {
        var _map$getBounds$toJSON = _this2.map.getBounds().toJSON(),
            north = _map$getBounds$toJSON.north,
            south = _map$getBounds$toJSON.south,
            east = _map$getBounds$toJSON.east,
            west = _map$getBounds$toJSON.west;

        var bounds = {
          northEast: { lat: north, lng: east },
          southWest: { lat: south, lng: west } };
        _this2.props.updateFilter('bounds', bounds);
      });
      google.maps.event.addListener(this.map, 'click', function (event) {
        var coords = getCoordsObj(event.latLng);
        _this2.handleClick(coords);
      });
    }
  }, {
    key: 'handleMarkerClick',
    value: function handleMarkerClick(bench) {
      this.props.history.push('benches/' + bench.id);
    }
  }, {
    key: 'handleClick',
    value: function handleClick(coords) {
      this.props.history.push({
        pathname: 'benches/new',
        search: 'lat=' + coords.lat + '&lng=' + coords.lng
      });
    }
  }, {
    key: 'render',
    value: function render() {
      return _react2.default.createElement(
        'div',
        { className: 'map', ref: 'map' },
        'Map'
      );
    }
  }]);

  return BenchMap;
}(_react2.default.Component);

exports.default = (0, _reactRouterDom.withRouter)(BenchMap);

/***/ }),

/***/ 85:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _reactRedux = __webpack_require__(17);

var _bench_actions = __webpack_require__(28);

var _selectors = __webpack_require__(86);

var _bench_show = __webpack_require__(152);

var _bench_show2 = _interopRequireDefault(_bench_show);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var mapStateToProps = function mapStateToProps(state, _ref) {
  var match = _ref.match;

  var benchId = parseInt(match.params.benchId);
  var bench = (0, _selectors.selectBench)(state, match.params.benchId);
  return {
    benchId: benchId,
    bench: bench
  };
};

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    fetchBench: function fetchBench(id) {
      return dispatch((0, _bench_actions.fetchBench)(id));
    }
  };
};

exports.default = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(_bench_show2.default);

/***/ }),

/***/ 86:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
   value: true
});
var selectBench = exports.selectBench = function selectBench(_ref, id) {
   var benches = _ref.benches,
       reviews = _ref.reviews;

   var bench = benches[id] || {};
   return bench;
};

var asArray = exports.asArray = function asArray(_ref2) {
   var benches = _ref2.benches;
   return Object.keys(benches).map(function (key) {
      return benches[key];
   });
};

/***/ }),

/***/ 87:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ProtectedRoute = exports.AuthRoute = undefined;

var _react = __webpack_require__(3);

var _react2 = _interopRequireDefault(_react);

var _reactRedux = __webpack_require__(17);

var _reactRouterDom = __webpack_require__(14);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Auth = function Auth(_ref) {
  var Component = _ref.component,
      path = _ref.path,
      loggedIn = _ref.loggedIn;
  return _react2.default.createElement(_reactRouterDom.Route, { path: path, render: function render(props) {
      return !loggedIn ? _react2.default.createElement(Component, props) : _react2.default.createElement(_reactRouterDom.Redirect, { to: '/' });
    } });
};

var Protected = function Protected(_ref2) {
  var Component = _ref2.component,
      path = _ref2.path,
      loggedIn = _ref2.loggedIn;
  return _react2.default.createElement(_reactRouterDom.Route, { path: path, render: function render(props) {
      return loggedIn ? _react2.default.createElement(Component, props) : _react2.default.createElement(_reactRouterDom.Redirect, { to: '/login' });
    } });
};

var mapStateToProps = function mapStateToProps(state) {
  return { loggedIn: Boolean(state.session.currentUser) };
};

var AuthRoute = exports.AuthRoute = (0, _reactRouterDom.withRouter)((0, _reactRedux.connect)(mapStateToProps, null)(Auth));

var ProtectedRoute = exports.ProtectedRoute = (0, _reactRouterDom.withRouter)((0, _reactRedux.connect)(mapStateToProps, null)(Protected));

/***/ }),

/***/ 9:
/***/ (function(module, exports) {

throw new Error("Module build failed: Error: ENOENT: no such file or directory, open '/Users/louiscruz/Desktop/app-academy-repos/curriculum/react/projects/bench_bnb/solution/node_modules/react-router/es/index.js'");

/***/ })

/******/ });
//# sourceMappingURL=bundle.js.map