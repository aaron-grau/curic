"use strict";

const BenchConstants = {
  BENCHES_RECEIVED: "BENCHES_RECEIVED",
  BENCH_RECEIVED: "BENCH_RECEIVED"
};

module.exports = BenchConstants;
