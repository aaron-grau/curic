"use strict";

const ErrorConstants = {
  SET_ERRORS: "SET_ERRORS",
  CLEAR_ERRORS: "CLEAR_ERRORS"
};

module.exports = ErrorConstants;
