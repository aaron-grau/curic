"use strict";

const FavoriteConstants = {
  FAVORITE_RECEIVED: "FAVORITE_RECEIVED",
  FAVORITE_REMOVED: "FAVORITE_REMOVED"
};

module.exports = FavoriteConstants;
