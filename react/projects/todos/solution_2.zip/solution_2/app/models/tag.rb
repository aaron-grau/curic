class Tag < ApplicationRecord
end
