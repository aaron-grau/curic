import React from 'react';

class Calculator extends React.Component{
  constructor(props){
    super(props);
    //your code here
  }

  //your code here

  render(){
    return (
      <div>
        <h1>Hello World</h1>
        //your code will replace this
      </div>
    );
  }
}

export default Calculator;
