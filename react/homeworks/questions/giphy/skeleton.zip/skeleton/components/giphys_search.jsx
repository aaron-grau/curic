import React, { Component } from 'react';

import GiphysIndex from './giphys_index';
