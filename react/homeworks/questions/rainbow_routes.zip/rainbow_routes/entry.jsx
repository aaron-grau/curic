"use strict";

const React = require('react');
const ReactDOM = require('react-dom');
const ReactRouter = require('react-router');

const Router = ReactRouter.Router;
const Route = ReactRouter.Route;
const IndexRoute = ReactRouter.IndexRoute;
const hashHistory = ReactRouter.hashHistory;

const Red = require('./components/red.jsx');
const Orange = require('./components/orange.jsx');
const Yellow = require('./components/yellow.jsx');
const Green = require('./components/green.jsx');
const Blue = require('./components/blue.jsx');
const Indigo = require('./components/indigo.jsx');
const Violet = require('./components/violet.jsx');


const Rainbow = React.createClass({
  render() {
    return(
      <div>
        <h1>Rainbow Router!</h1>

        <h4 onClick={this.addRed}>Red</h4>
        <h4 onClick={this.addGreen}>Green</h4>
        <h4 onClick={this.addBlue}>Blue</h4>
        <h4 onClick={this.addViolet}>Violet</h4>

        <div id="rainbow">
          {this.props.children}
        </div>
      </div>
    );
  },

  addRed() {
    // your code here
  },

  addGreen() {
    // your code here
  },

  addBlue() {
    // your code here
  },

  addViolet() {
    // your code here
  }
});

const routes = (
  <Route path="/" component={Rainbow}>
    // your code here 
  </Route>
);

document.addEventListener("DOMContentLoaded", function () {
  ReactDOM.render(
    <Router history={hashHistory}>{routes}</Router>,
    document.getElementById('main')
  );
});
