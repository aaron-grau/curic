const React = require('react');

module.exports = React.createClass({
  render() {
    return(
      <div>
        <h2 className="green"></h2>
      </div>
    );
  }
});
