const React = require('react');

module.exports = React.createClass({
  render() {
    return(
      <div>
        <h3 className="orange"></h3>
      </div>
    );
  }
});
