import React from 'react';

const Indigo = () => {
  return (
    <div>
      <h3 className="indigo"></h3>
    </div>
  );
};

export default Indigo;
