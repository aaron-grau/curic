import React from 'react';

const Orange = () => {
  return (
    <div>
      <h3 className="orange"></h3>
    </div>
  );
};

export default Orange;
