import React from 'react';

const Green = () => (
  <div>
    <h2 className="green"></h2>
  </div>
);

export default Green;
