const React = require('react');

module.exports = React.createClass({
  render() {
    return(
      <div>
        <h3 className="yellow"></h3>
      </div>
    );
  }
});
