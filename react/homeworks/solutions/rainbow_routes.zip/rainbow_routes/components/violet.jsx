import React from 'react';

const Violet = () => {
  return (
    <div>
      <h2 className="violet"></h2>
    </div>
  );
};

export default Violet;
