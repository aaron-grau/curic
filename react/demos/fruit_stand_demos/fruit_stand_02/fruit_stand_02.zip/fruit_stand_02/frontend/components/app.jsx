import React from 'react';
import FruitStandContainer from './fruit_stand/fruit_stand_container';

const App = () => (
  <div className='app'>
    <FruitStandContainer />
  </div>
);

export default App;
