## 5 Practical Examples!

### How to use
+ download both files: [`five_examples.html`][html] and [`style.css`][css]
+ put them in the same folder
+ open `five_examples.html`
+ play around with the widgets
+ pour over the source code, understand every line

[html]: https://github.com/appacademy/react-flux-curriculum/raw/master/w7d1/five_examples/five_examples.html
[css]: https://github.com/appacademy/react-flux-curriculum/raw/master/w7d1/five_examples/style.css
