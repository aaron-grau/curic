# Click Counter Demo

*Download zip [here][demo-raw].*

To run:
* Navigate to the project directory and run `npm install`.
* The `postinstall` script in the `package.json` will take care of
  running `webpack` to generate the bundle, but run `npm run webpack` if you
  plan to make changes to the code
* Open `index.html` in your browser

[demo-raw]: ../click-counter.zip?raw=true
