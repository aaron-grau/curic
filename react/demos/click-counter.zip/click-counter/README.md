# Click Counter Demo

To run:
* Navigate to project directory and run `npm install`
* Run `webpack` to generate the bundle
  * (or `webpack -w` if you plan to make changes to the code)
* Open `index.html` in your browser