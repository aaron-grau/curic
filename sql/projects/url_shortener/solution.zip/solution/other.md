# w3d3: [URL Shortener][description]

Check out:

* [`db/migrate`](./db/migrate)
* [`app/models`](./app/models)

[description]: https://github.com/appacademy/curriculum/tree/master/sql/projects/url_shortener
