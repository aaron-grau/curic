# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
URLShortener::Application.config.secret_token = 'a339e6ec7351496a428dccebdca8efd9e4f5ab4f59a6f3f2b1f752081a37368a9e99d0719d3fc7cae8e49dfd286eb416932c39dd97f65c3b7a8ec85aa5b50ba9'
