require 'test_helper'

class NobelTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
