# Solutions to Intro Rails Homework
