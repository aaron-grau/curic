* These specs are leftover from an old Ruby exercise. We've left it so
  you have some more RSpec that you can read and study :-)
