class Temperature
  # TODO: your code goes here!
end
