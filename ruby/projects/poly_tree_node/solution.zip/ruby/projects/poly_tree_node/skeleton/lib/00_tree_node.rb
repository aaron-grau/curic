class PolyTreeNode

end